
#Test Subtotal

A brief description of what this project does and who it's for


## Authors

- (https://github.com/Alexandrgentlmen)


## Feedback

If you have any feedback, please reach out to us at agusletsov@gmail.com


## Tech Stack

**Client:** React, Redux,RTK Query  

**API:** SpaceX: https://github.com/r-spacex/SpaceX-API





## NPM Commands for start

npm i 
npm run dev